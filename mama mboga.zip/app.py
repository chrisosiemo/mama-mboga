"""Mama Mboga Co - Flask web app based on the project wireframes.
Run:  pip install -r requirements.txt  &&  python app.py
Open: http://localhost:5000 (PC)  or  http://<your-PC-IP>:5000 (phone on same Wi-Fi)
"""
import os, io, csv, json, time, math, hmac, uuid, signal, random, sqlite3, logging, datetime, threading, collections
import urllib.request, urllib.error
from urllib.parse import urlparse
from flask import Flask, render_template_string, request, redirect, url_for, session, jsonify, g
from jinja2 import DictLoader
from werkzeug.security import generate_password_hash, check_password_hash

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("mamamboga")

app = Flask(__name__)
app.config.update(MAX_CONTENT_LENGTH=64 * 1024,            # reject huge request bodies (413)
                  SESSION_COOKIE_SAMESITE="Lax", SESSION_COOKIE_HTTPONLY=True)
app.secret_key = os.environ.get("AGRI_SECRET", "change-this-secret-key")
DB_PATH = os.environ.get("AGRI_DB", os.path.join(os.path.dirname(os.path.abspath(__file__)), "agrisystem.db"))
API_KEY = os.environ.get("AGRI_API_KEY", "dev-key")  # IoT devices send this in the X-API-Key header

if app.secret_key == "change-this-secret-key" or API_KEY == "dev-key":
    log.warning("Using default AGRI_SECRET / AGRI_API_KEY. Set your own before sharing the app.")

# ---------- Rate limiting (in memory, per IP) ----------
_hits, _hlock = {}, threading.Lock()

def too_many(bucket, limit, window):
    now, k = time.time(), (bucket, request.remote_addr or "?")
    with _hlock:
        q = _hits.setdefault(k, collections.deque())
        while q and now - q[0] > window:
            q.popleft()
        if len(q) >= limit:
            return True
        q.append(now)
        if len(_hits) > 5000:  # drop idle entries
            for kk in [kk for kk, v in _hits.items() if not v]:
                del _hits[kk]
        return False

# ---------- Request logging and request ids (simple tracing) ----------
@app.before_request
def _start():
    g.t0, g.rid = time.time(), (request.headers.get("X-Request-ID") or uuid.uuid4().hex[:12])[:40]

@app.after_request
def _finish(resp):
    rid = getattr(g, "rid", "-")
    resp.headers["X-Request-ID"] = rid
    log.info("%s %s %s %.0fms rid=%s", request.method, request.path, resp.status_code,
             (time.time() - getattr(g, "t0", time.time())) * 1000, rid)
    return resp

# ---------- Database (SQLite) ----------
def db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH, timeout=10)  # wait up to 10s if another writer holds the lock
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys=ON")
    return g.db

@app.teardown_appcontext
def close_db(_):
    d = g.pop("db", None)
    if d:
        d.close()

# Each entry runs once, in order; PRAGMA user_version records how many have been applied.
MIGRATIONS = [
    "CREATE INDEX IF NOT EXISTS idx_readings_metric ON readings(metric, id)",
    "CREATE TABLE IF NOT EXISTS seen_keys(key TEXT PRIMARY KEY, ts TEXT DEFAULT CURRENT_TIMESTAMP)",
]

def init_db():
    c = sqlite3.connect(DB_PATH, timeout=10)
    try:
        c.execute("PRAGMA journal_mode=WAL")  # readers do not block the writer
    except sqlite3.DatabaseError:
        pass
    c.executescript("""
    CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL, pw_hash TEXT NOT NULL, created TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS posts(id INTEGER PRIMARY KEY, user TEXT NOT NULL, text TEXT NOT NULL, likes INTEGER DEFAULT 0, created TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS readings(id INTEGER PRIMARY KEY, device TEXT, metric TEXT NOT NULL, value REAL NOT NULL, ts TEXT DEFAULT CURRENT_TIMESTAMP);
    """)
    done = c.execute("PRAGMA user_version").fetchone()[0]
    for i, sql in enumerate(MIGRATIONS[done:], start=done + 1):
        c.execute(sql)
        c.execute("PRAGMA user_version=%d" % i)
    if c.execute("SELECT COUNT(*) FROM posts").fetchone()[0] == 0:
        c.executemany("INSERT INTO posts(user,text,likes) VALUES(?,?,?)", [
            ("Shamba Boy", "Mama Mboga Co has helped me plan irrigation this season.", 12),
            ("Mapesa", "Early pest detection keeps crops healthy and yields high.", 8)])
    c.commit(); c.close()

# ---------- Live weather (Open-Meteo: free, no API key) ----------
PLACES = {"Nairobi": (-1.286, 36.817), "Nakuru": (-0.303, 36.080), "Kisumu": (-0.091, 34.768),
          "Eldoret": (0.514, 35.270), "Mombasa": (-4.043, 39.668), "Kitale": (1.019, 35.002)}
_wcache, _wlock = {}, threading.Lock()

def get_weather(place="Nairobi"):
    """Returns (data, source). Cached 10 min when live; after a failure the sample data is reused for 5 min
    so an offline server does not wait on the network for every page view."""
    lat, lon = PLACES.get(place, PLACES["Nairobi"])
    hit = _wcache.get(place)
    if hit and time.time() < hit[0]:
        return hit[1], hit[2]
    with _wlock:  # only one request refreshes a place; the others reuse its result
        hit = _wcache.get(place)
        if hit and time.time() < hit[0]:
            return hit[1], hit[2]
        url = ("https://api.open-meteo.com/v1/forecast?latitude=%s&longitude=%s&timezone=auto&forecast_days=3"
               "&current=temperature_2m,relative_humidity_2m,wind_speed_10m"
               "&daily=temperature_2m_max,precipitation_probability_max" % (lat, lon))
        try:
            j = json.loads(_http(url, 5, retries=2))
            cur, day = j["current"], j["daily"]
            names = ["Today", "Tomorrow", "Day 3"]
            data = dict(temp=round(cur["temperature_2m"], 1), hum=int(cur["relative_humidity_2m"]),
                        wind=round(cur["wind_speed_10m"]), rain=int(day["precipitation_probability_max"][0] or 0),
                        days=[(names[i], round(day["temperature_2m_max"][i])) for i in range(3)])
            _wcache[place] = (time.time() + 600, data, "live")
            return data, "live"
        except Exception as e:
            log.warning("weather unavailable for %s: %s", place, e)
            data = dict(temp=round(random.uniform(22, 32), 1), hum=random.randint(45, 80), wind=random.randint(4, 18),
                        rain=random.randint(5, 60), days=[("Today", 29), ("Tomorrow", 31), ("Day 3", 28)])
            _wcache[place] = (time.time() + 300, data, "sample")
            return data, "sample"

# ---------- Kenya market data ----------
# 1) WFP Food Prices for Kenya (Humanitarian Data Exchange): retail/wholesale prices by market, monthly.
# 2) World Bank Open Data: national agriculture indicators.
# KAMIS (kamis.kilimo.go.ke) has no public API that we could find, so the app links to it instead of scraping it.
DATA_DIR = os.environ.get("AGRI_DATA_DIR", os.path.dirname(os.path.abspath(__file__)))
PRICES_CSV = os.path.join(DATA_DIR, "kenya_food_prices.csv")
HDX_PACKAGE = "https://data.humdata.org/api/3/action/package_show?id=wfp-food-prices-for-kenya"
HDX_FALLBACK = ("https://data.humdata.org/dataset/e0d3fba6-f9a2-45d7-b949-140c455197ff/resource/"
                "517ee1bf-2437-4f8c-aa1b-cb9925b9d437/download/wfp_food_prices_ken.csv")
WB_URL = "https://api.worldbank.org/v2/country/KE/indicator/%s?format=json&mrnev=1"
WB_INDICATORS = [("NV.AGR.TOTL.ZS", "Agriculture share of GDP", "%"), ("SL.AGR.EMPL.ZS", "Jobs in agriculture", "%"),
                 ("AG.YLD.CREL.KG", "Cereal yield", " kg/ha"), ("AG.PRD.FOOD.XD", "Food production index", ""),
                 ("FP.CPI.TOTL.ZG", "Consumer price inflation", "%")]
_P = {"series": None, "t": 0, "ttl": 0, "latest": None}
_WB = {"t": 0, "items": []}

_breaker, _block = {}, threading.Lock()  # host -> [consecutive failures, open until]

def _http(url, timeout=20, retries=3):
    """GET with exponential backoff + jitter, and a circuit breaker per host:
    after 3 failed calls in a row the host is skipped for 5 minutes."""
    host = urlparse(url).netloc
    with _block:
        st = _breaker.setdefault(host, [0, 0.0])
        if st[1] > time.time():
            raise OSError("circuit open for %s" % host)
    for attempt in range(retries):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "mama-mboga-co/1.0"})
            with urllib.request.urlopen(req, timeout=timeout) as r:
                body = r.read()
            with _block:
                _breaker[host] = [0, 0.0]
            return body
        except Exception as e:
            client_error = isinstance(e, urllib.error.HTTPError) and e.code < 500 and e.code != 429
            if attempt == retries - 1 or client_error:
                with _block:
                    st = _breaker.setdefault(host, [0, 0.0])
                    st[0] += 1
                    if st[0] >= 3:
                        st[1] = time.time() + 300
                        log.warning("circuit opened for %s", host)
                raise
            time.sleep(min(4, 0.5 * 2 ** attempt) * random.uniform(0.5, 1.5))

def _download_prices():
    url = HDX_FALLBACK
    try:  # ask HDX for the current CSV link so the app keeps working when the file is replaced
        meta = json.loads(_http(HDX_PACKAGE, 10, retries=2))
        for r in meta["result"]["resources"]:
            if r.get("format", "").upper() == "CSV" and "qc" not in r.get("url", "").lower() \
               and "quickcharts" not in r.get("name", "").lower():
                url = r.get("download_url") or r["url"]
                break
    except Exception as e:
        log.warning("HDX lookup failed, using fallback link: %s", e)
    text = _http(url, 60).decode("utf-8-sig")
    tmp = PRICES_CSV + ".tmp"          # write then rename, so readers never see a half-written file
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(text)
    os.replace(tmp, PRICES_CSV)
    return text

def _parse_prices(text):
    """-> {(market, commodity, unit, pricetype): [(date, price), ...]} plus county per market"""
    series, county = {}, {}
    for row in csv.DictReader(io.StringIO(text)):
        d = (row.get("date") or "")
        if not d[:1].isdigit():  # skips the HXL tag row (#date, #adm1+name ...)
            continue
        try:
            price = float(row["price"])
        except (KeyError, ValueError):
            continue
        key = (row["market"], row["commodity"], row.get("unit", ""), row.get("pricetype", "Retail"))
        series.setdefault(key, []).append((d, price))
        county[row["market"]] = row.get("admin1", "")
    for v in series.values():
        v.sort()
    return series, county

_plock = threading.Lock()

def load_prices():
    """Loads WFP prices (cached on disk for 7 days, in memory for a day). Returns series dict or None.
    A lock makes sure only one request downloads while the others wait for the result."""
    now = time.time()
    if _P["series"] is not None and now - _P["t"] < _P["ttl"]:
        return _P["series"] or None
    with _plock:
        now = time.time()
        if _P["series"] is not None and now - _P["t"] < _P["ttl"]:
            return _P["series"] or None
        text = None
        fresh = os.path.exists(PRICES_CSV) and now - os.path.getmtime(PRICES_CSV) < 7 * 86400
        if not fresh:
            try:
                text = _download_prices()
            except Exception as e:
                log.warning("price download failed: %s", e)
        if text is None and os.path.exists(PRICES_CSV):
            with open(PRICES_CSV, encoding="utf-8") as f:
                text = f.read()
        series, county = _parse_prices(text) if text else ({}, {})
        _P.update(series=series, county=county, t=now, ttl=86400 if series else 600)
        return series or None

def worldbank_facts():
    now = time.time()
    if now - _WB["t"] < 86400:
        return _WB["items"]
    items = []
    for code, label, unit in WB_INDICATORS:
        try:
            j = json.loads(_http(WB_URL % code, 6))
            rec = j[1][0]
            if rec["value"] is not None:
                items.append((label, round(rec["value"], 1), unit, rec["date"]))
        except Exception:
            continue
    _WB.update(t=now if items else now - 86000, items=items)  # retry sooner if nothing came back
    return items

def market_view(market, commodity):
    series = load_prices()
    if not series:
        return None
    all_last = max(v[-1][0] for v in series.values())
    cutoff = (datetime.date.fromisoformat(all_last[:10]) - datetime.timedelta(days=400)).isoformat()
    live = {k: v for k, v in series.items() if v[-1][0] >= cutoff}
    count = {}
    for k in live:
        count[k[0]] = count.get(k[0], 0) + 1
    markets = sorted(count)
    if market not in count:
        market = "Nairobi" if "Nairobi" in count else max(count, key=count.get)
    rows = []
    for (m, c, u, t), v in live.items():
        if m != market:
            continue
        prev = v[-2][1] if len(v) > 1 else None
        chg = round((v[-1][1] - prev) / prev * 100, 1) if prev else None
        rows.append(dict(commodity=c, unit=u, type=t, price=v[-1][1], date=v[-1][0][:10], chg=chg))
    rows.sort(key=lambda r: (r["commodity"], r["type"]))
    commodities = sorted({r["commodity"] for r in rows})
    if commodity not in commodities and commodities:
        commodity = commodities[0]
    hist = []
    for (m, c, u, t), v in live.items():
        if m == market and c == commodity and (not hist or t == "Retail"):
            hist = v[-36:]
    spark = None
    if len(hist) > 1:
        lo, hi = min(p for _, p in hist), max(p for _, p in hist)
        span = (hi - lo) or 1
        pts = " ".join("%.1f,%.1f" % (i * 296 / (len(hist) - 1) + 2, 76 - (p - lo) / span * 70) for i, (_, p) in enumerate(hist))
        spark = dict(points=pts, lo=lo, hi=hi, start=hist[0][0][:7], end=hist[-1][0][:7])
    return dict(markets=markets, market=market, county=_P["county"].get(market, ""), rows=rows, commodities=commodities,
                commodity=commodity, spark=spark, last=all_last[:10])

# ---------- Registered agrovets directory (agrovets.csv) ----------
# Columns: name,type,county,town,phone,license_no,regulator,source,verified
# Add rows (or replace the file) with data from the official registers; the page reloads it when the file changes.
AGROVETS_CSV = os.path.join(DATA_DIR, "agrovets.csv")
_AV = {"mtime": None, "rows": []}

def load_agrovets():
    try:
        m = os.path.getmtime(AGROVETS_CSV)
    except OSError:
        return []
    if _AV["mtime"] != m:
        with open(AGROVETS_CSV, encoding="utf-8-sig", newline="") as f:
            rows = [{k: (v or "").strip() for k, v in r.items() if k} for r in csv.DictReader(f)]
        _AV.update(mtime=m, rows=[r for r in rows if r.get("name")])
    return _AV["rows"]

# ---------- Sensor readings (IoT devices post here) ----------
def latest(metric):
    r = db().execute("SELECT value FROM readings WHERE metric=? ORDER BY id DESC LIMIT 1", (metric,)).fetchone()
    return r["value"] if r else None

def sensor_cards(spec):
    """spec: [(label, metric, unit, sample_range)] -> ([(label,value,unit)], from_devices?)"""
    out, real = [], False
    for label, metric, unit, rng in spec:
        v = latest(metric)
        if v is not None:
            real = True
        else:
            v = random.randint(*rng)
        out.append((label, round(v, 1) if isinstance(v, float) else v, unit))
    return out, real

# ---------- Data (replace with sensors / database / APIs later) ----------
MENU = [
    ("weather", "Weather forecasting"), ("crops", "Crop monitoring"),
    ("pests", "Pest & disease management"), ("resources", "Resource & storage management"),
    ("market", "Market & agrovet insights"), ("community", "Community interaction"),
    ("officers", "Agricultural officers"), ("vets", "Veterinarian"),
    ("education", "Mama Mboga education"),
]
SUBMENUS = {
    "weather": ["Local weather", "Regional weather", "IoT live weather", "Greenhouse weather", "Soil temperature", "Poultry temperature", "AI weather", "Weather statistics"],
    "pests": ["Pest tracking", "Disease tracking", "Identify disease", "Disease solution", "Integrated pest management", "Monitoring and early detection"],
    "market": ["Local market", "County market", "Cross-county market", "Cross-country market", "African market", "Market prices"],
}
VIDEOS = [("Precision spraying basics", "3:00"), ("Drone crop scouting", "8:40"), ("Greenhouse monitoring", "20:00")]
POLICY = ("Policy and state capability: investments to work with and support governments to strengthen "
          "execution and coordination, enhance transparency and accountability, and enable a better policy "
          "environment. Systems development: investments to build downstream delivery systems while "
          "supporting the local private sector to scale technologies and services for better productivity and incomes.")
PRICES = [("Maize (90kg bag)", 3600, "up"), ("Beans (90kg bag)", 9800, "flat"), ("Potatoes (50kg bag)", 2400, "down"),
          ("Tomatoes (crate)", 4200, "up"), ("Kales / sukuma wiki (bag)", 1500, "flat"), ("Cabbages (126kg bag)", 1800, "down"),
          ("Rice (50kg bag)", 6500, "up"), ("Onions (bag)", 5200, "flat")]
OFFICERS = [("Local extension officer", "+254 700 000 001"), ("County agricultural officer", "+254 700 000 002"),
            ("Online advisory desk", "+254 700 000 003"), ("Hotline", "+254 700 000 004"),
            ("Crop protection officer", "+254 700 000 005"), ("Soil & water officer", "+254 700 000 006")]
VETS = [("Livestock vet - Nakuru", "+254 700 100 001"), ("Poultry specialist", "+254 700 100 002"), ("Mobile clinic", "+254 700 100 003")]
PESTS = [("Fall armyworm", "Maize", "High", "Scout weekly; apply recommended bio-pesticide early."),
         ("Late blight", "Potato / tomato", "Medium", "Remove infected leaves; improve spacing and airflow."),
         ("Aphids", "Kale / cabbage", "Low", "Spray soapy water or neem; encourage ladybirds.")]
COURSES = ["Soil health basics", "Water-saving irrigation", "Integrated pest management", "Post-harvest storage",
           "Reading market trends", "Agricultural policy and your rights"]

# ---------- Templates ----------
BASE = """<!doctype html><html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{{ title }} - Mama Mboga Co</title>
<style>
:root{--ink:#1d2417;--soil:#140a0a;--leaf:#2f7d32;--lime:#a6c94a;--sun:#f2a93b;--paper:#f6f5ee;--card:#fff;--muted:#6b7365;--line:#dcdccf}
*{box-sizing:border-box}body{margin:0;font:16px/1.5 "Segoe UI",system-ui,sans-serif;background:var(--paper);color:var(--ink)}
a{color:inherit;text-decoration:none}
.shell{display:grid;grid-template-columns:260px 1fr;min-height:100vh}
.side{background:var(--soil);color:#f3efe6;padding:20px 14px;display:flex;flex-direction:column;gap:4px;position:sticky;top:0;height:100vh;overflow:auto}
.logo{display:flex;align-items:center;gap:10px;font-weight:700;margin-bottom:16px}
.logo i{width:40px;height:40px;border-radius:50%;background:radial-gradient(circle at 35% 30%,var(--lime),var(--leaf));display:block}
.side a{padding:10px 12px;border-radius:8px;font-size:.95rem}
.side a:hover,.side a.on{background:#2a1a14;color:var(--lime)}
.side .out{margin-top:auto;border-top:1px solid #3a2a24;padding-top:14px}
.hero{min-height:170px;padding:22px 28px;color:#fff;display:flex;justify-content:space-between;align-items:flex-start;gap:16px;
 background:linear-gradient(180deg,rgba(0,0,0,.25),rgba(0,0,0,.55)),radial-gradient(circle at 80% 10%,var(--sun),transparent 40%),linear-gradient(120deg,#4d6b1f,#2f7d32 60%,#6a4a2b)}
.hero h1{margin:0;font-size:1.9rem}
.top{display:flex;gap:18px;align-items:center;flex-wrap:wrap}
.top a:hover{text-decoration:underline}.top .btn{background:var(--soil);padding:6px 14px;border-radius:6px}
main{padding:24px 28px;max-width:1200px}
h2{margin:0 0 12px}h3{margin:0 0 6px}
.grid{display:grid;gap:16px;grid-template-columns:repeat(auto-fill,minmax(230px,1fr))}
.card{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:16px}
.chips{display:flex;flex-wrap:wrap;gap:8px;margin:0 0 18px}
.chip{padding:6px 14px;border:1px solid var(--line);background:#fff;border-radius:99px;cursor:pointer;font-size:.9rem}
.chip.on{background:var(--leaf);color:#fff;border-color:var(--leaf)}
.home{display:grid;grid-template-columns:2fr 1fr;gap:20px}
.player{background:var(--soil);border-radius:12px;color:#fff;overflow:hidden}
.screen{aspect-ratio:16/10;background:linear-gradient(160deg,#6b4b2a,#3b2a18 55%,#2f7d32);display:grid;place-items:center}
.screen button{width:70px;height:70px;border-radius:50%;border:0;background:var(--sun);font-size:1.6rem;cursor:pointer}
.bar{height:6px;background:#444}.bar b{display:block;height:100%;width:50%;background:#d93025}
.pl{padding:10px 14px;display:flex;justify-content:space-between;font-size:.9rem}
.list{display:flex;flex-direction:column;gap:10px}
.vid{display:flex;gap:10px;align-items:center;background:#fff;border:1px solid var(--line);border-radius:10px;padding:8px;cursor:pointer}
.vid span.t{width:64px;height:44px;border-radius:6px;background:linear-gradient(135deg,var(--lime),var(--leaf))}
.vid small{margin-left:auto;color:var(--muted)}
.policy{grid-column:1/-1}.policy h3{display:inline-block;background:var(--soil);color:#fff;padding:4px 12px;border-radius:4px}
.big{font-size:2.3rem;font-weight:700}.muted{color:var(--muted)}
.up{color:#1b7a2f}.down{color:#c0392b}.flat{color:var(--muted)}
table{width:100%;border-collapse:collapse}td,th{padding:10px;border-bottom:1px solid var(--line);text-align:left}
.gauge{height:10px;background:#e5e5d8;border-radius:6px;overflow:hidden}.gauge b{display:block;height:100%;background:var(--sun)}
input,textarea,select{width:100%;padding:10px;border:1px solid var(--line);border-radius:8px;font:inherit;margin-bottom:10px}
button.go,.go{background:var(--leaf);color:#fff;border:0;border-radius:8px;padding:10px 18px;font:inherit;cursor:pointer;display:inline-block}
.tag{font-size:.75rem;padding:2px 8px;border-radius:99px;background:#eee}
.High{background:#f7d4d0}.Medium{background:#fbe8c4}.Low{background:#d9efd2}
footer{background:var(--soil);color:#cfc8b8;padding:18px 28px;display:flex;justify-content:space-between;flex-wrap:wrap;gap:10px;font-size:.85rem}
.menu-btn{display:none;background:none;border:1px solid #fff8;color:#fff;border-radius:6px;padding:6px 10px;font-size:1.1rem}
@media(max-width:860px){
 .shell{grid-template-columns:1fr}
 .side{position:fixed;inset:0 25% 0 0;height:100vh;z-index:20;transform:translateX(-100%);transition:transform .2s}
 .side.open{transform:none}.menu-btn{display:inline-block}
 .home{grid-template-columns:1fr}main{padding:16px}.hero{padding:16px}.hero h1{font-size:1.4rem}
}
:focus-visible{outline:3px solid var(--sun);outline-offset:2px}
@media(prefers-reduced-motion:reduce){*{transition:none!important}}
</style></head><body><div class="shell">
<nav class="side" id="side" aria-label="Main menu">
 <a class="logo" href="{{ url_for('home') }}"><i></i>Mama Mboga Co</a>
 {% for key,label in menu %}<a href="{{ url_for('module', key=key) }}" class="{{ 'on' if active==key }}">{{ label }}</a>
 {% if key=='market' %}<a href="{{ url_for('agrovets') }}" class="{{ 'on' if active=='agrovets' }}" style="padding-left:28px;font-size:.9rem">Registered agrovets</a>{% endif %}{% endfor %}
 <div class="out">{% if session.user %}<span class="muted">Hi, {{ session.user }}</span><br><a href="{{ url_for('logout') }}">Logout</a>
 {% else %}<a href="{{ url_for('login') }}">Login</a> &middot; <a href="{{ url_for('signup') }}">Sign up</a>{% endif %}</div>
</nav>
<div>
 <header class="hero"><div class="top"><button class="menu-btn" onclick="document.getElementById('side').classList.toggle('open')" aria-label="Menu">&#9776;</button><h1>Mama Mboga Co</h1></div>
  <div class="top"><a href="{{ url_for('home') }}">HOME</a><a href="{{ url_for('about') }}">ABOUT</a><a href="{{ url_for('module', key='officers') }}">CONTACTS</a>
  {% if not session.user %}<a class="btn" href="{{ url_for('signup') }}">Sign up</a>{% endif %}</div></header>
 <main>{% block body %}{% endblock %}</main>
 <footer><span>Agricultural Transformation Framework &middot; agrisystempeers@info.com</span><span><a href="#">Privacy policy</a> &middot; <a href="#">Terms &amp; conditions</a></span></footer>
</div></div>
<script>document.querySelectorAll('.chips').forEach(g=>g.addEventListener('click',e=>{if(e.target.classList.contains('chip')){g.querySelectorAll('.chip').forEach(c=>c.classList.remove('on'));e.target.classList.add('on');}}));</script>
</body></html>"""

HOME = """{% extends 'base' %}{% block body %}
<div class="home">
 <div class="player"><div class="screen"><button id="pp" onclick="this.textContent=this.textContent=='\u25B6'?'\u23F8':'\u25B6'">\u25B6</button></div>
  <div class="bar"><b></b></div><div class="pl"><span>Precision spraying basics</span><span>15:00 / 30:00</span></div></div>
 <div class="list"><h3>Next</h3>{% for t,d in videos %}<div class="vid"><span class="t"></span>{{ t }}<small>{{ d }}</small></div>{% endfor %}</div>
 <div class="card policy"><h3>Policy education</h3><p>{{ policy }}</p></div>
</div>{% endblock %}"""

MODULE = """{% extends 'base' %}{% block body %}
<h2>{{ title }}</h2>
{% if subs %}<div class="chips">{% for s in subs %}<span class="chip {{ 'on' if loop.first }}" tabindex="0">{{ s }}</span>{% endfor %}</div>{% endif %}
{% if key=='weather' %}
 <form method="get" style="max-width:260px"><select name="place" onchange="this.form.submit()" aria-label="Location">
  {% for p in places %}<option {{ 'selected' if p==place }}>{{ p }}</option>{% endfor %}</select></form>
 <div class="grid">
  <div class="card"><div class="muted">Temperature</div><div class="big" id="t">{{ d.temp }}\u00b0C</div></div>
  <div class="card"><div class="muted">Humidity</div><div class="big" id="h">{{ d.hum }}%</div></div>
  <div class="card"><div class="muted">Wind</div><div class="big">{{ d.wind }} km/h</div></div>
  <div class="card"><div class="muted">Rain probability</div><div class="big">{{ d.rain }}%</div></div>
 </div><h3 style="margin-top:22px">3-day outlook</h3>
 <div class="grid">{% for day,t in d.days %}<div class="card"><b>{{ day }}</b><div class="big">{{ t }}\u00b0</div></div>{% endfor %}</div>
 <p class="muted">{% if source=='live' %}Live data from Open-Meteo for {{ place }}.{% else %}Offline: showing sample values (no internet or weather service unavailable).{% endif %}</p>
{% elif key=='crops' %}
 <div class="grid">{% for n,v,u in d.sensors %}<div class="card"><div class="muted">{{ n }}</div><div class="big">{{ v }}{{ u }}</div><div class="gauge"><b style="width:{{ v if v<=100 else 100 }}%"></b></div></div>{% endfor %}</div>
 <p class="muted">{{ 'Latest readings from your devices.' if real else 'Sample values until a device sends data (see README).' }}</p>
 <h3 style="margin-top:22px">Crop health</h3><div class="card"><table>{% for c,s in d.crops %}<tr><td>{{ c }}</td><td>{{ s }}</td></tr>{% endfor %}</table></div>
{% elif key=='pests' %}
 <div class="grid">{% for n,c,r,t in pests %}<div class="card"><h3>{{ n }}</h3><span class="tag {{ r }}">{{ r }} risk</span> <span class="muted">{{ c }}</span><p>{{ t }}</p></div>{% endfor %}</div>
{% elif key=='resources' %}
 <div class="grid">{% for n,v,u in d.res %}<div class="card"><div class="muted">{{ n }}</div><div class="big">{{ v }}{{ u }}</div><div class="gauge"><b style="width:{{ v if v<=100 else 100 }}%"></b></div></div>{% endfor %}</div>
 <p class="muted">{{ 'Latest readings from your devices.' if real else 'Sample values until a device sends data (see README).' }}</p>
 <h3 style="margin-top:22px">Storage monitoring</h3><div class="card"><table>{% for n,s in d.store %}<tr><td>{{ n }}</td><td>{{ s }}</td></tr>{% endfor %}</table></div>
{% elif key=='market' %}
 <div class="card"><table><tr><th>Produce</th><th>Price (KES)</th><th>Trend</th></tr>
 {% for n,p,t in prices %}<tr><td>{{ n }}</td><td>{{ '{:,}'.format(p) }}</td><td class="{{ t }}">{{ {'up':'\u25B2 Rising','down':'\u25BC Falling','flat':'\u25AC Steady'}[t] }}</td></tr>{% endfor %}</table></div>
 <p class="muted">Sample prices. Check prices and trends before you sell to make informed decisions.</p>
{% elif key=='education' %}
 <div class="grid">{% for c in courses %}<div class="card"><h3>{{ c }}</h3><p class="muted">Video lessons and short quizzes.</p><a class="go" href="{{ url_for('home') }}">Start</a></div>{% endfor %}</div>
{% elif key in ('officers','vets') %}
 <div class="grid">{% for n,p in people %}<div class="card"><h3>{{ n }}</h3><p>{{ p }}</p><a class="go" href="tel:{{ p.replace(' ','') }}">Call</a></div>{% endfor %}</div>
{% endif %}{% endblock %}"""

COMMUNITY = """{% extends 'base' %}{% block body %}
<h2>Community interaction</h2>
<div class="chips"><span class="chip on">Message</span><span class="chip">Video call</span><span class="chip">Status</span><span class="chip">Clips</span></div>
<form class="card" method="post" style="margin-bottom:16px"><textarea name="text" rows="2" placeholder="Share a tip or ask farmers and officers..." required></textarea>
 <button class="go">Post</button></form>
<div class="list" id="posts">{% for p in posts %}<div class="card"><b>{{ p.user }}</b><p>{{ p.text }}</p>
 <button class="chip" onclick="like({{ p.id }},this)">&#128077; <span>{{ p.likes }}</span></button></div>{% endfor %}</div>
<script>function like(i,b){fetch('/api/like/'+i,{method:'POST'}).then(r=>r.json()).then(j=>b.querySelector('span').textContent=j.likes)}</script>
{% endblock %}"""

MARKET = """{% extends 'base' %}{% block body %}
<h2>Market &amp; agrovet insights</h2>
<div class="chips"><a class="chip {{ 'on' if tab=='prices' }}" href="{{ url_for('module', key='market') }}">Market prices</a><a class="chip {{ 'on' if tab=='agrovets' }}" href="{{ url_for('agrovets') }}">Registered agrovets</a></div>
{% if v %}
<form method="get" class="grid" style="grid-template-columns:repeat(auto-fit,minmax(200px,1fr))">
 <label>Market<select name="market" onchange="this.form.submit()">{% for m in v.markets %}<option {{ 'selected' if m==v.market }}>{{ m }}</option>{% endfor %}</select></label>
 <label>Commodity<select name="commodity" onchange="this.form.submit()">{% for c in v.commodities %}<option {{ 'selected' if c==v.commodity }}>{{ c }}</option>{% endfor %}</select></label>
</form>
<p class="muted">{{ v.market }}{{ ', ' + v.county if v.county }}. Prices in KES from the WFP Food Prices database (via HDX). Latest record: {{ v.last }}.
 For today's prices also check <a href="https://kamis.kilimo.go.ke" target="_blank" rel="noopener"><u>KAMIS</u></a>.</p>
{% if v.spark %}<div class="card" style="margin-bottom:16px"><h3>{{ v.commodity }} price history</h3>
 <svg viewBox="0 0 300 80" style="width:100%;height:120px" role="img" aria-label="Price history chart"><polyline points="{{ v.spark.points }}" fill="none" stroke="#2f7d32" stroke-width="2.5" vector-effect="non-scaling-stroke"/></svg>
 <div class="muted" style="display:flex;justify-content:space-between"><span>{{ v.spark.start }}</span><span>Low {{ '{:,.0f}'.format(v.spark.lo) }} &ndash; High {{ '{:,.0f}'.format(v.spark.hi) }}</span><span>{{ v.spark.end }}</span></div></div>{% endif %}
<div class="card" style="overflow-x:auto"><table><tr><th>Commodity</th><th>Unit</th><th>Type</th><th>Price (KES)</th><th>Change</th><th>Date</th></tr>
{% for r in v.rows %}<tr><td>{{ r.commodity }}</td><td>{{ r.unit }}</td><td>{{ r.type }}</td><td>{{ '{:,.0f}'.format(r.price) }}</td>
<td class="{{ 'up' if r.chg and r.chg>0 else 'down' if r.chg and r.chg<0 else 'flat' }}">{% if r.chg is none %}-{% else %}{{ '%+.1f'|format(r.chg) }}%{% endif %}</td><td>{{ r.date }}</td></tr>{% endfor %}</table></div>
{% else %}
<p class="muted">Live market data is not available right now (no internet and no saved copy). Showing sample prices.</p>
<div class="card"><table><tr><th>Produce</th><th>Price (KES)</th><th>Trend</th></tr>
{% for n,p,t in prices %}<tr><td>{{ n }}</td><td>{{ '{:,}'.format(p) }}</td><td class="{{ t }}">{{ {'up':'Rising','down':'Falling','flat':'Steady'}[t] }}</td></tr>{% endfor %}</table></div>
{% endif %}
{% if facts %}<h3 style="margin-top:24px">Kenya agriculture at a glance</h3>
<div class="grid">{% for label,val,unit,yr in facts %}<div class="card"><div class="muted">{{ label }}</div><div class="big">{{ val }}{{ unit }}</div><div class="muted">{{ yr }}, World Bank</div></div>{% endfor %}</div>{% endif %}
{% endblock %}"""

AGROVETS = """{% extends 'base' %}{% block body %}
<h2>Market &amp; agrovet insights</h2>
<div class="chips"><a class="chip {{ 'on' if tab=='prices' }}" href="{{ url_for('module', key='market') }}">Market prices</a><a class="chip {{ 'on' if tab=='agrovets' }}" href="{{ url_for('agrovets') }}">Registered agrovets</a></div>
<h3>Registered agrovets</h3>
<form method="get" class="grid" style="grid-template-columns:repeat(auto-fit,minmax(180px,1fr));align-items:end">
 <label>Search<input name="q" value="{{ q }}" placeholder="Name or town"></label>
 <label>County<select name="county"><option value="">All counties</option>{% for c in counties %}<option {{ 'selected' if c==county }}>{{ c }}</option>{% endfor %}</select></label>
 <label>Type<select name="type"><option value="">All types</option>{% for t in types %}<option {{ 'selected' if t==typ }}>{{ t }}</option>{% endfor %}</select></label>
 <button class="go" style="margin-bottom:10px">Search</button>
</form>
<p class="muted">Showing {{ rows|length }} of {{ total }} matching ({{ all }} in the directory). Confirm a licence on the official register before you buy:
 <a href="https://kenyavetboard.or.ke/en/registers" target="_blank" rel="noopener"><u>Kenya Veterinary Board</u></a> (animal health products) and the
 <a href="https://pcpb.go.ke" target="_blank" rel="noopener"><u>Pest Control Products Board</u></a> (pesticides). Only buy pesticides from licensed agrovets, never from hawkers.</p>
{% if not all %}<div class="card">No agrovets loaded yet. Add an <code>agrovets.csv</code> file (see README).</div>{% endif %}
<div class="grid">{% for r in rows %}<div class="card"><h3>{{ r.name }}</h3>
 <span class="tag">{{ r.type or 'Agrovet' }}</span>
 <p style="margin:8px 0 0">{{ [r.town, r.county]|select|join(', ') or 'Location not listed' }}</p>
 {% if r.phone %}<p style="margin:4px 0"><a href="tel:{{ r.phone.replace(' ','') }}"><u>{{ r.phone }}</u></a></p>{% endif %}
 <p class="muted" style="margin:4px 0;font-size:.85rem">{% if r.license_no %}Licence {{ r.license_no }}. {% endif %}{{ r.regulator }}{% if r.verified %}, checked {{ r.verified }}{% endif %}</p>
 {% if r.source %}<p class="muted" style="margin:0;font-size:.8rem">Source: {{ r.source }}</p>{% endif %}</div>{% endfor %}</div>
{% if pages>1 %}<p style="margin-top:16px">{% if n>1 %}<a class="chip" href="{{ url_for('agrovets', q=q, county=county, type=typ, page=n-1) }}">Previous</a> {% endif %}Page {{ n }} of {{ pages }}
 {% if n<pages %} <a class="chip" href="{{ url_for('agrovets', q=q, county=county, type=typ, page=n+1) }}">Next</a>{% endif %}</p>{% endif %}
{% endblock %}"""

LOGIN = """{% extends 'base' %}{% block body %}
<div class="card" style="max-width:420px;margin:auto"><h2>{{ 'Sign up' if mode=='signup' else 'Login' }}</h2>
{% if error %}<p class="down" role="alert">{{ error }}</p>{% endif %}
<form method="post"><input name="user" placeholder="Username" autocomplete="username" required minlength="3">
<input name="pw" type="password" placeholder="Password (6+ characters)" autocomplete="{{ 'new-password' if mode=='signup' else 'current-password' }}" required minlength="6">
<button class="go">{{ 'Create account' if mode=='signup' else 'Login' }}</button></form>
<p class="muted">{% if mode=='signup' %}Have an account? <a href="{{ url_for('login') }}"><u>Login</u></a>{% else %}New here? <a href="{{ url_for('signup') }}"><u>Sign up</u></a>{% endif %}</p></div>{% endblock %}"""

ABOUT = """{% extends 'base' %}{% block body %}
<h2>About Mama Mboga Co</h2>
<p>Mama Mboga Co helps farmers track water use and fertilizer, get pest and disease alerts, follow market prices, learn agricultural policy, and talk with officers, buyers and agrovets in one place.</p>
<h3>Why it matters</h3><p>Inefficient agrisystems contribute to seasonal food shortages and lower farmer incomes. Small-scale farmers are hit hardest by limited training, machinery, finance and information.</p>
{% endblock %}"""

app.jinja_loader = DictLoader({"base": BASE})

def page(tpl, **kw):
    t = app.jinja_env.from_string(tpl)
    return t.render(menu=MENU, session=session, **kw)

# ---------- Routes ----------
@app.route("/")
def home():
    return page(HOME, title="Home", active=None, videos=VIDEOS, policy=POLICY)

@app.route("/about")
def about():
    return page(ABOUT, title="About", active=None)

@app.route("/m/<key>", methods=["GET", "POST"])
def module(key):
    labels = dict(MENU)
    if key not in labels:
        return redirect(url_for("home"))
    if key == "community":
        if request.method == "POST":
            text = request.form.get("text", "").strip()[:500]
            if text:
                db().execute("INSERT INTO posts(user,text) VALUES(?,?)", (session.get("user", "Guest"), text))
                db().commit()
            return redirect(url_for("module", key="community"))
        posts = db().execute("SELECT * FROM posts ORDER BY id DESC LIMIT 50").fetchall()
        return page(COMMUNITY, title=labels[key], active=key, posts=posts)
    if key == "market":
        v = market_view(request.args.get("market", ""), request.args.get("commodity", ""))
        return page(MARKET, title=labels[key], active=key, tab="prices", v=v, prices=PRICES, facts=worldbank_facts())
    d, real, place, source = {}, False, "Nairobi", "sample"
    if key == "weather":
        place = request.args.get("place", "Nairobi")
        d, source = get_weather(place)
    elif key == "crops":
        d["sensors"], real = sensor_cards([("Soil moisture", "soil_moisture", "%", (30, 70)),
            ("Soil temperature", "soil_temp", "\u00b0C", (18, 30)), ("Leaf wetness", "leaf_wetness", "%", (10, 60)),
            ("Sunlight", "sunlight", "%", (40, 95))])
        d["crops"] = [("Maize - Plot A", "Healthy"), ("Beans - Plot B", "Needs water" if d["sensors"][0][1] < 35 else "Healthy"),
                      ("Kale - Plot C", "Check for aphids")]
    elif key == "resources":
        d["res"], real = sensor_cards([("Water tank", "water_tank", "%", (40, 90)),
            ("Fertilizer stock", "fertilizer_stock", "%", (20, 80)), ("Irrigation pump", "pump_on", "% on", (100, 100))])
        d["store"] = [("Grain store", "Dry, 14% moisture"), ("Cold room", "4\u00b0C, normal"), ("Seed store", "Low stock")]
    people = OFFICERS if key == "officers" else VETS
    return page(MODULE, title=labels[key], key=key, active=key, subs=SUBMENUS.get(key), d=d, pests=PESTS,
                prices=PRICES, courses=COURSES, people=people, places=list(PLACES), place=place, source=source, real=real)

def _auth(mode):
    error = None
    if request.method == "POST":
        if too_many("auth", 10, 300):  # 10 attempts per 5 minutes per IP
            return page(LOGIN, title="Login", active=None, mode=mode,
                        error="Too many attempts. Wait a few minutes and try again."), 429
        user, pw = request.form.get("user", "").strip(), request.form.get("pw", "")
        row = db().execute("SELECT * FROM users WHERE username=?", (user,)).fetchone()
        if mode == "signup":
            if len(user) < 3 or len(pw) < 6:
                error = "Use a username of 3+ characters and a password of 6+ characters."
            elif row:
                error = "That username is taken. Choose another or log in."
            else:
                try:
                    db().execute("INSERT INTO users(username,pw_hash) VALUES(?,?)", (user, generate_password_hash(pw)))
                    db().commit()
                except sqlite3.IntegrityError:  # someone took the name between our check and insert
                    error = "That username is taken. Choose another or log in."
                else:
                    session.clear()
                    session["user"] = user
                    return redirect(url_for("home"))
        elif row and check_password_hash(row["pw_hash"], pw):
            session.clear()
            session["user"] = user
            return redirect(url_for("home"))
        else:
            log.info("failed login for %r from %s", user[:40], request.remote_addr)
            error = "Wrong username or password."
    return page(LOGIN, title="Sign up" if mode == "signup" else "Login", active=None, mode=mode, error=error)

@app.route("/login", methods=["GET", "POST"])
def login():
    return _auth("login")

@app.route("/signup", methods=["GET", "POST"])
def signup():
    return _auth("signup")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("home"))

_prune = {"t": 0.0}

@app.route("/api/sensors", methods=["GET", "POST"])
def api_sensors():
    """POST JSON from a device: {"device":"field1","soil_moisture":42,"water_tank":75,"reading_id":"abc123"}
    with header X-API-Key. Send the same reading_id (or an Idempotency-Key header) when retrying: it is saved once."""
    if request.method == "POST":
        if too_many("sensor", 120, 60):
            return jsonify(error="too many requests"), 429, {"Retry-After": "60"}
        sent = request.headers.get("X-API-Key", "").encode()
        if not hmac.compare_digest(sent, API_KEY.encode()):  # constant-time comparison
            log.warning("bad API key from %s", request.remote_addr)
            return jsonify(error="bad API key"), 401
        j = request.get_json(silent=True)
        if not isinstance(j, dict):
            return jsonify(error="send a JSON object"), 400
        key = (request.headers.get("Idempotency-Key") or str(j.get("reading_id") or ""))[:100]
        if key:
            try:
                db().execute("INSERT INTO seen_keys(key) VALUES(?)", (key,))
            except sqlite3.IntegrityError:
                return jsonify(saved=0, duplicate=True)
        vals = [(k, v) for k, v in j.items() if k not in ("device", "reading_id") and isinstance(v, (int, float))
                and not isinstance(v, bool) and math.isfinite(v)][:20]
        for k, v in vals:
            db().execute("INSERT INTO readings(device,metric,value) VALUES(?,?,?)", (str(j.get("device", "device"))[:60], str(k)[:60], v))
        if time.time() - _prune["t"] > 3600:  # keep 30 days of readings so the table cannot grow forever
            _prune["t"] = time.time()
            db().execute("DELETE FROM readings WHERE ts < datetime('now','-30 days')")
            db().execute("DELETE FROM seen_keys WHERE ts < datetime('now','-7 days')")
        db().commit()
        return jsonify(saved=len(vals))
    rows = db().execute("SELECT metric, value, ts FROM readings WHERE id IN (SELECT MAX(id) FROM readings GROUP BY metric)").fetchall()
    return jsonify({r["metric"]: {"value": r["value"], "time": r["ts"]} for r in rows})

@app.route("/health")
def health():
    """For uptime monitors and load balancers: 200 when the app and database respond."""
    try:
        db().execute("SELECT 1").fetchone()
        return jsonify(status="ok")
    except Exception:
        log.exception("health check failed")
        return jsonify(status="error"), 503

@app.route("/agrovets")
def agrovets():
    rows = load_agrovets()
    q = request.args.get("q", "").strip()
    county, typ = request.args.get("county", ""), request.args.get("type", "")
    ql = q.lower()
    found = [r for r in rows if (not ql or ql in r["name"].lower() or ql in r.get("town", "").lower())
             and (not county or r.get("county") == county) and (not typ or (r.get("type") or "Agrovet") == typ)]
    try:
        n = max(1, int(request.args.get("page", 1)))
    except ValueError:
        n = 1
    per = 48
    pages = max(1, -(-len(found) // per))
    n = min(n, pages)
    return page(AGROVETS, title="Registered agrovets", active="agrovets", tab="agrovets", rows=found[(n - 1) * per:n * per],
                total=len(found), all=len(rows), counties=sorted({r["county"] for r in rows if r.get("county")}),
                types=sorted({r.get("type") or "Agrovet" for r in rows}), q=q, county=county, typ=typ, n=n, pages=pages)

@app.route("/api/prices")
def api_prices():
    """JSON of latest prices: /api/prices?market=Nairobi&commodity=Maize"""
    v = market_view(request.args.get("market", ""), request.args.get("commodity", ""))
    if not v:
        return jsonify(error="market data unavailable"), 503
    return jsonify(market=v["market"], rows=v["rows"] if not request.args.get("commodity") else
                   [r for r in v["rows"] if r["commodity"] == v["commodity"]])

@app.route("/api/like/<int:i>", methods=["POST"])
def like(i):
    db().execute("UPDATE posts SET likes=likes+1 WHERE id=?", (i,))
    db().commit()
    r = db().execute("SELECT likes FROM posts WHERE id=?", (i,)).fetchone()
    return (jsonify(likes=r["likes"]) if r else (jsonify(error="not found"), 404))

init_db()  # also runs when started with a production server (waitress / gunicorn)

if __name__ == "__main__":
    host, port = os.environ.get("AGRI_HOST", "0.0.0.0"), int(os.environ.get("AGRI_PORT", "5000"))
    threading.Thread(target=load_prices, daemon=True).start()  # warm the price data so the first visitor does not wait
    if os.environ.get("AGRI_DEBUG") == "1":  # development only: never use on a shared network
        app.run(host=host, port=port, debug=True)
    else:
        def _stop(*_):
            log.info("shutting down: finishing in-flight requests")
            raise SystemExit(0)
        signal.signal(signal.SIGTERM, _stop)
        try:
            from waitress import serve
            log.info("serving on http://%s:%s", host, port)
            serve(app, host=host, port=port, threads=8)  # waits for running requests on Ctrl+C / SIGTERM
        except ImportError:
            log.warning("waitress not installed (pip install waitress); using Flask's built-in server")
            app.run(host=host, port=port, debug=False)
