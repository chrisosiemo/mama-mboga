# Mama Mboga Co

    pip install -r requirements.txt
    python app.py          # http://localhost:5000  (phone: http://<PC-IP>:5000)

It runs on the Waitress production server (installed by requirements.txt). Ctrl+C lets running requests finish first.
Set `AGRI_DEBUG=1` only for development: debug mode exposes a code console and must never run on a shared network.

The SQLite file `agrisystem.db` is created on first run.

## Settings (environment variables, optional)
- `AGRI_SECRET`  – session secret (set a long random value before sharing the app)
- `AGRI_API_KEY` – key IoT devices must send (default `dev-key`)
- `AGRI_DB`      – path of the database file
- `AGRI_HOST` / `AGRI_PORT` – bind address (default 0.0.0.0) and port (default 5000)

## Send sensor data from a device
    curl -X POST http://localhost:5000/api/sensors ^
      -H "X-API-Key: dev-key" -H "Content-Type: application/json" ^
      -d "{\"device\":\"field1\",\"soil_moisture\":42,\"soil_temp\":21,\"water_tank\":75,\"fertilizer_stock\":60}"

Metrics used by the pages: soil_moisture, soil_temp, leaf_wetness, sunlight (Crop monitoring);
water_tank, fertilizer_stock, pump_on (Resource & storage). `GET /api/sensors` returns the latest values.

## Weather
Live forecasts come from Open-Meteo (no key needed) for Nairobi, Nakuru, Kisumu, Eldoret, Mombasa and Kitale.
Add towns in the `PLACES` dict. If offline, the page shows sample values and says so.

## Kenya agriculture and food market data
- **Market prices**: WFP Food Prices for Kenya (Humanitarian Data Exchange). The app finds the current CSV through the HDX API,
  saves it as `kenya_food_prices.csv` (refreshed every 7 days) and shows latest price, change vs previous record,
  and a price history chart per market and commodity. JSON: `/api/prices?market=Nairobi&commodity=Beans`.
  If you are offline it uses the saved copy; with no copy it shows sample prices.
- **National facts**: World Bank Open Data (agriculture share of GDP, jobs in agriculture, cereal yield,
  food production index, inflation), cached for a day.
- **KAMIS** (kamis.kilimo.go.ke): no public API was found, so the Market page links to it. If KAMIS gives you
  data access or CSV exports, add a loader next to `load_prices()`.

## Registered agrovets directory
Open **Market & agrovet insights > Registered agrovets** (also in the sidebar). Search by name or town and filter by county or type.
Data lives in `agrovets.csv` (columns: `name,type,county,town,phone,license_no,regulator,source,verified`).
The page reloads automatically when you replace or edit the file, and shows 48 results per page, so thousands of rows are fine.

The bundled file only has the 14 veterinary drug manufacturers named in the March 2024 government list.
To build the full directory, collect rows from the official registers and save them in the same format:
- Kenya Veterinary Board registers: https://kenyavetboard.or.ke/en/registers (animal health premises)
- Pest Control Products Board (pcpb.go.ke) (pesticide outlets)
- County agriculture / livestock offices, and the Ministry of Interior's published lists
Keep the `source` and `verified` columns filled so farmers can see where each entry came from.

## Reliability and safety notes
- `GET /health` returns 200 when the app and database respond (use it for uptime monitors).
- Sensor posts: send a `reading_id` (or `Idempotency-Key` header) and retry safely; the same id is saved once.
  Limits: 120 posts/minute per IP, 20 metrics per post, 64 KB per request. Readings older than 30 days are deleted.
- Login and sign up allow 10 attempts per 5 minutes per IP.
- Outside calls (weather, prices, World Bank) retry with exponential backoff and jitter, and pause for 5 minutes
  after repeated failures. Only one request refreshes a cache at a time.
- Database changes: add a new SQL line to `MIGRATIONS` in `app.py`; each runs once per database.
- Logs include a request id (also returned in the `X-Request-ID` header).
- Caches and rate limits are kept in memory, so run a single process (Waitress threads are fine).
